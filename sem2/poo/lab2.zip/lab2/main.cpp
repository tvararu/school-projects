
#include <cassert>
#include <iostream>
#include <string>
#include <vector>
#include <fstream>
using namespace std;

// mi-am zis ca ar fi o aplicatie practica draguta un parser basic de html asa ca am scris si niste clase mici ajutatoare pentru asta
#include "html.cpp"
#include "tree.cpp"

int main (int argc, char const *argv[])
{
  Tree ex0(Tag("0")), ex1(Tag("1")), ex2(Tag("2")), ex3(Tag("3")), ex4(Tag("4")), ex5(Tag("5")), ex6(Tag("6"));

  // operator+ si operator+=
  ex0 = ex0 + ex1;
  ex0 += ex4;
  ex1 += ex2;
  ex1 += ex3 += ex5 += ex6;
  
  // parcurgerile in latime si adancime
  cout << "Breadth first search: " << ex0.bfs() << endl;
  cout << "Depth first search: " << ex0.dfs() << endl;
  
  // operator<<
  cout << ex0;
  
  // inaltimea unui (sub)arbore
  cout << "Height of ex0: " << ex0.get_height() << endl;
  cout << "Height of ex3: " << ex3.get_height() << endl;
  
  // vectorul cu frunzele sub forma de nod, se poate adapta usor sa fie aduse ca subarbori fara copii
  cout << ex0.leaves().size() << endl;
  
  // outputez ex0 intr-un fisier ca sa il pot citi
  ofstream out ("arbore.out");
  out << ex0;
  out.close ();
  
  // operator>> nu am apucat sa il termin, nu face toata citirea cum trebuie dar e
  // 90% done si mi-am zis ca nu are sens sa il tai pe tot. cand m-am apucat de el a
  // durat ore intregi in care am cunoscut termeni mirobolanti precum "shallow
  // copy", "deep copy", "reference counting" si mi-am dat seama ca aproape tot 
  // programul e gresit.
  // pe langa faptul ca merge pe jumatate, mai si creeaza memory leaks.
  Tree fromFile;
  ifstream in ("arbore.out");
  in >> fromFile;
  in.close ();
  
  cout << "Read from file:\n" << fromFile;
  
  // at least face ce mi-am dorit, o pagina web
  
  Tree dom(Tag("html"));
  
  // head
  Tree head(Tag("head"));
  
  Tree title(Tag("title"));
  Tree title_content(Tag("Yay! Output!", 1));
  title += title_content;
  head += title;
  
  Tree bootstrap(Tag("link").attr("href", "http://twitter.github.io/bootstrap/assets/css/bootstrap.css").attr("rel", "stylesheet"));
  head += bootstrap;
  
  dom += head;
  
  // body
  Tree body(Tag("body"));
  
  Tree container(Tag("div").attr("class", "container"));
  
  Tree hero(Tag("div").attr("class", "hero-unit"));
  Tree greeting(Tag("h1"));
  Tree greeting_content(Tag("Hello!", 1));
  greeting += greeting_content;
  hero += greeting;
  Tree paragraph(Tag("p"));
  Tree paragraph_content(Tag("Pagina asta probabil ca nu o sa arate ok daca nu exista o conexiune activa la net. Si fiindca nu am stiut ce sa scriu mai departe aici, am pus programul sa isi outputeze codul sursa. Aproape, ar mai trebui si global substitution pentru &lt; si &gt;.", 1));
  paragraph += paragraph_content;
  hero += paragraph;
  container += hero;
  
  Tree pre(Tag("pre"));
  string quine;
  in.open ("main.cpp");
  while (in) {
    string line; getline (in, line);
    quine += line + "\n";
  }
  in.close ();
  Tree pre_content(Tag(quine, 1));
  pre += pre_content;
  container += pre;
  
  body += container;
  
  dom += body;
  
  out.open ("index.html");
  out << "<!DOCTYPE html>\n";
  out << dom;
  out.close ();
  
  // deschideti index.html cu un browser :)
  
  return 0;
}